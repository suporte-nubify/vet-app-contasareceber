import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";
import fs from "fs";
import path from "path";

const prisma = new PrismaClient();

type SeedRow = {
  data: string;
  tutor: string | null;
  pet: string | null;
  procedimento: string | null;
  total: number | null;
  estabelecimento: string | null;
  pagamento: string | null;
  conferido: boolean;
};

async function upsertNome(
  model: "tutor" | "procedimento" | "estabelecimento" | "formaPagamento",
  nome: string
) {
  const clean = nome.trim();
  if (model === "tutor") {
    return prisma.tutor.upsert({
      where: { nome: clean },
      update: {},
      create: { nome: clean },
    });
  }
  if (model === "procedimento") {
    return prisma.procedimento.upsert({
      where: { nome: clean },
      update: {},
      create: { nome: clean },
    });
  }
  if (model === "estabelecimento") {
    return prisma.estabelecimento.upsert({
      where: { nome: clean },
      update: {},
      create: { nome: clean },
    });
  }
  return prisma.formaPagamento.upsert({
    where: { nome: clean },
    update: {},
    create: { nome: clean },
  });
}

async function main() {
  const username = process.env.AUTH_DEMO_USER || "admin";
  const password = process.env.AUTH_DEMO_PASSWORD || "admin";
  const passwordHash = await bcrypt.hash(password, 10);

  await prisma.user.upsert({
    where: { username },
    update: { passwordHash },
    create: { username, passwordHash },
  });

  const seedPath = path.join(__dirname, "seed-data.json");
  const rows = JSON.parse(fs.readFileSync(seedPath, "utf8")) as SeedRow[];

  const existing = await prisma.contaReceber.count();
  if (existing > 0) {
    console.log(`Já existem ${existing} contas — seed de lançamentos ignorado.`);
    return;
  }

  for (const row of rows) {
    if (!row.data || !row.pet || row.total == null || !row.procedimento || !row.estabelecimento) {
      continue;
    }

    const procedimento = await upsertNome("procedimento", row.procedimento);
    const estabelecimento = await upsertNome("estabelecimento", row.estabelecimento);
    const tutor = row.tutor ? await upsertNome("tutor", row.tutor) : null;
    const forma = row.pagamento
      ? await upsertNome("formaPagamento", row.pagamento)
      : null;

    const data = new Date(row.data);
    await prisma.contaReceber.create({
      data: {
        data,
        tutorId: tutor?.id,
        nomePet: row.pet.trim(),
        procedimentoId: procedimento.id,
        valor: row.total,
        estabelecimentoId: estabelecimento.id,
        formaPagamentoId: forma?.id,
        recebido: Boolean(row.conferido),
        recebidoEm: row.conferido ? data : null,
      },
    });
  }

  console.log("Seed concluído.");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
