# Contas a Receber

App web simples (mobile-first) para substituir a planilha de contas a receber: lançamentos por tutor/pet/procedimento/estabelecimento, formas de pagamento, flag **recebido/conferido**, filtros e painel com 3 indicadores.

Pasta local sugerida no Windows:

```text
C:\Projetos\App - Contas a Receber
```

Clone ou copie o repositório para essa pasta e use Docker (recomendado) ou Node local.

---

## Versão 1 — pronta para rodar com Docker

### Pré-requisitos

- [Docker Desktop](https://www.docker.com/products/docker-desktop/) instalado e em execução no Windows

### Subir o app

No PowerShell ou terminal, dentro da pasta do projeto:

```powershell
cd "C:\Projetos\App - Contas a Receber"
docker compose up --build
```

Abra: [http://localhost:3847](http://localhost:3847)

### Credenciais demo

| Campo   | Valor   |
| ------- | ------- |
| Usuário | `admin` |
| Senha   | `admin` |

O banco SQLite fica em `.\data\app.db` (persistente entre reinícios). Na primeira subida o container copia o seed da planilha **Setembro 26**.

Para parar:

```powershell
docker compose down
```

---

## Desenvolvimento local (sem Docker)

Requer Node.js 20+.

```powershell
copy .env.example .env
npm install
npm run db:setup
npm run dev
```

App em [http://localhost:3847](http://localhost:3847) — mesmas credenciais `admin` / `admin`.

---

## O que o app faz

- Login com usuário e senha
- Painel: recebido (3 meses), inadimplentes, a receber no mês
- CRUD de contas alinhado à planilha (DATA, TUTOR, PET, PROCEDIMENTO, TOTAL, Estabelecimento, Pagamento, conferido)
- Cadastros com criação inline ao selecionar
- Filtros na lista de contas
- Interface em português (Brasil), pensada para iPhone

Plano de produto: ver documentação no Project (`docs/plano-app.md`) quando disponível no ambiente Cursor.
