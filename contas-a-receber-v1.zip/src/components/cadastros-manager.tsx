"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

type Item = { id: string; nome: string };

type TipoKey = "tutores" | "procedimentos" | "estabelecimentos" | "formas-pagamento";

const labels: Record<TipoKey, string> = {
  tutores: "Tutores",
  procedimentos: "Procedimentos",
  estabelecimentos: "Estabelecimentos",
  "formas-pagamento": "Formas de pagamento",
};

export function CadastrosManager({
  initial,
}: {
  initial: Record<TipoKey, Item[]>;
}) {
  const [tab, setTab] = useState<TipoKey>("tutores");
  const [data, setData] = useState(initial);
  const [nome, setNome] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function add() {
    const n = nome.trim();
    if (!n) return;
    setBusy(true);
    setError("");
    const res = await fetch(`/api/cadastros/${tab}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ nome: n }),
    });
    const json = await res.json();
    setBusy(false);
    if (!res.ok) {
      setError(json.error || "Erro ao cadastrar");
      return;
    }
    setData((d) => ({
      ...d,
      [tab]: [...d[tab].filter((x) => x.id !== json.id), json].sort((a, b) =>
        a.nome.localeCompare(b.nome, "pt-BR")
      ),
    }));
    setNome("");
  }

  return (
    <div>
      <div className="mb-4 flex flex-wrap gap-2">
        {(Object.keys(labels) as TipoKey[]).map((key) => (
          <button
            key={key}
            type="button"
            onClick={() => setTab(key)}
            className={`min-h-11 rounded-xl px-3 text-sm font-semibold ${
              tab === key ? "bg-teal-700 text-white" : "bg-white border border-stone-300 text-stone-700"
            }`}
          >
            {labels[key]}
          </button>
        ))}
      </div>

      <div className="mb-4 flex gap-2">
        <Input
          placeholder={`Novo ${labels[tab].slice(0, -1).toLowerCase()}…`}
          value={nome}
          onChange={(e) => setNome(e.target.value)}
        />
        <Button type="button" disabled={busy} onClick={add}>
          Adicionar
        </Button>
      </div>
      {error && <p className="mb-3 text-sm text-red-600">{error}</p>}

      <ul className="space-y-2">
        {data[tab].map((item) => (
          <li
            key={item.id}
            className="rounded-xl border border-stone-200 bg-white px-4 py-3 text-base font-medium text-stone-800"
          >
            {item.nome}
          </li>
        ))}
        {data[tab].length === 0 && (
          <li className="rounded-xl border border-dashed border-stone-300 p-4 text-center text-stone-500">
            Nenhum cadastro ainda.
          </li>
        )}
      </ul>
    </div>
  );
}
