import Link from "next/link";
import { prisma } from "@/lib/prisma";
import { monthBounds } from "@/lib/dates";
import { formatBRL } from "@/lib/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { LogoutButton } from "@/components/logout-button";

export const dynamic = "force-dynamic";

async function sumWhere(where: Parameters<typeof prisma.contaReceber.aggregate>[0]["where"]) {
  const agg = await prisma.contaReceber.aggregate({
    where,
    _sum: { valor: true },
    _count: true,
  });
  return { total: agg._sum.valor ?? 0, count: agg._count };
}

export default async function DashboardPage() {
  const { m0, m1, mMinus3 } = monthBounds();

  const [recebido3m, inadimplentes, mesCorrente, abertas] = await Promise.all([
    sumWhere({
      recebido: true,
      recebidoEm: { gte: mMinus3, lt: m1 },
    }),
    sumWhere({
      recebido: false,
      data: { lt: m0 },
    }),
    sumWhere({
      recebido: false,
      data: { gte: m0, lt: m1 },
    }),
    prisma.contaReceber.count({ where: { recebido: false } }),
  ]);

  return (
    <main className="px-4 pt-6">
      <header className="mb-6 flex items-start justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl font-semibold text-teal-950">Contas a Receber</h1>
          <p className="mt-1 text-sm text-stone-600">Resumo do seu fluxo de recebimentos</p>
        </div>
        <LogoutButton />
      </header>

      <div className="space-y-3">
        <Card className="border-teal-200 bg-gradient-to-br from-teal-800 to-teal-700 text-white">
          <CardHeader>
            <CardTitle className="text-teal-100">Valor recebido — últimos 3 meses</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="font-display text-3xl font-semibold tracking-tight">
              {formatBRL(recebido3m.total)}
            </p>
            <p className="mt-1 text-sm text-teal-100/90">{recebido3m.count} lançamento(s)</p>
          </CardContent>
        </Card>

        <Card className="border-amber-200 bg-amber-50">
          <CardHeader>
            <CardTitle className="text-amber-900">Valores inadimplentes</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="font-display text-3xl font-semibold text-amber-950">
              {formatBRL(inadimplentes.total)}
            </p>
            <p className="mt-1 text-sm text-amber-800/80">
              Não recebidos com data em meses anteriores · {inadimplentes.count} item(ns)
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>A receber no mês corrente</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="font-display text-3xl font-semibold text-stone-900">
              {formatBRL(mesCorrente.total)}
            </p>
            <p className="mt-1 text-sm text-stone-500">
              Em aberto neste mês · {mesCorrente.count} item(ns)
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="mt-6 grid grid-cols-2 gap-3">
        <Link
          href="/contas/nova"
          className="flex min-h-14 items-center justify-center rounded-2xl bg-teal-700 px-4 text-center text-base font-semibold text-white"
        >
          Nova conta
        </Link>
        <Link
          href="/contas?status=aberto"
          className="flex min-h-14 items-center justify-center rounded-2xl border border-stone-300 bg-white px-4 text-center text-base font-semibold text-stone-800"
        >
          Ver em aberto ({abertas})
        </Link>
      </div>
    </main>
  );
}
